package Const;

public class Const {
    public static final String Main_URL = "https://kidkiddos.com/";
    public static final String Contact_Us_URL = "https://kidkiddos.com/pages/contact-us";


}
