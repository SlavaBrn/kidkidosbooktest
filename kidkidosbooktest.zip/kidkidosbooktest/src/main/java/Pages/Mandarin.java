package Pages;

public class Mandarin extends BasePage{
    public static final String Mandarin_Header = "//h1[text()= 'Mandarin Chinese - 中文']";
    public boolean isHeaderVisible(){
        return elementExists(Mandarin_Header);
    }
}
