package Pages;

public class Blog extends BasePage {
    public static final String Blog_Header = "//h1[text()= 'Blog']";
    public boolean isHeaderVisible(){
        return elementExists(Blog_Header);
    }
}
