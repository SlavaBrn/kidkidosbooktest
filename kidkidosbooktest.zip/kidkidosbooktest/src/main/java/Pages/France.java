package Pages;

public class France extends  BasePage{
    public static final String French_Header = "//h1[text()= 'French - Français']";
    public boolean isHeaderVisible(){
        return elementExists(French_Header);
    }
}
